<?php include('server.php') ?>
<?php
	$db = mysqli_connect('localhost', 'root', '', 'user');
	$query = "SELECT * FROM ride";
	$result = mysqli_query($db, $query);
	$row = mysqli_fetch_assoc($result);	
?>
<!DOCTYPE html>
<html>
<head>
  <title>Add Ride</title>
  <link rel="stylesheet" type="text/css" href="style.css">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="stylesheet" type="text/css" href="css/util.css">
	<link rel="stylesheet" type="text/css" href="css/main.css">
	    <script type="text/javascript" src="jquery-1.4.2.min.js"></script>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
</head>
<style>
body {font-family: Arial, Helvetica, sans-serif;}

.navbar {
  width: 100%;
  background-color: #555;
  overflow: auto;
}

.navbar a {
  float: right;
  padding: 12px;
  color: white;
  text-decoration: none;
  font-size: 18px;
}
.logo a {
  float: left;
  padding: 8px 30px 0px 30px;  
}
.navbar a:hover {
  background-color: #000;
}

.active {
  background-color: blue;
}

@media screen and (max-width: 500px) {
  .navbar a {
    float: none;
    display: block;
  }
}
</style>
<body>
<div class="navbar">
	<div class="logo">
		<a><img src="images/logo.png" class="imageHeader" title="Home Page" alt="Go to home" width="120" 
		height="38" position="left"/></a>
	</div>
	
<?php  if (isset($_SESSION['username'])) : ?>
    		<a href="trip.php"><i></i>Welcome <strong><?php echo $_SESSION['username']; ?></strong>
    	<p> <a href="index.html?logout='1'" style="color: white;">logout</a> </p>
    <?php endif ?>
	<a class='active' href="addride.php"><i class="fa fa-fw fa-user"></i> Add Ride</a>
	<a  href="trip.php"><i class="fa fa-fw fa-search"></i> Trips</a> 
</div>	
<body>
  <div class="header">
  	<h2>Add Ride</h2>
  </div>
	
  <form method="post" action="rideprocess.php">
  
  	<div class="input-group">
  	  <label>From</label>
  	  <input type="text" name="initial" id="initial">
  	</div>
  	<div class="input-group">
  	  <label>Destination</label>
  	  <input type="text" id="destination" name="destination">
  	</div>
  	<div class="input-group">
  	  <label>Date</label>
  	  <input type="date" id="date" name="date">
  	</div>
	 	<div class="input-group">
  	  <label>Time</label>
  	  <input type="time" id="time" name="time">
  	</div>
  	<div class="input-group">
  	  <label>Seat</label>
  	  <input type="text" id="seat" name="seat">
  	</div>
	<div class="input-group">
  	  <label>Fare</label>
  	  <input type="text" id="fare" name="fare">
  	</div>
  	<div class="input-group">
  	  <button type="submit" class="btn" name="submit">Submit</button>
  	</div>
  </form>
  <br><br><br><br><br>
  <!-- Footer -->
			<div class="navbar">
			  <a href="#"><i class="fa fa-facebook"></i></a> 
			  <a href="#"><i class="fa fa-google-plus"></i></a> 
			  <a href="#"><i class="fa fa-twitter"></i></a> 
			  <a href="#">@COOL POOL</a>				
			</div>
</body>
</html>