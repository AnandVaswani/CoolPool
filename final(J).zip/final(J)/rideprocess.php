<?php
session_start();

// initializing variables
$username = "";
$email    = "";
$errors = array(); 

// connect to the database
$db = mysqli_connect('localhost', 'root', '', 'user');

// REGISTER USER
if (isset($_POST['submit'])) {
  // receive all input values from the form
  $initial = mysqli_real_escape_string($db, $_POST['initial']);
  $destination = mysqli_real_escape_string($db, $_POST['destination']);
  $date = mysqli_real_escape_string($db, $_POST['date']);
  $time = mysqli_real_escape_string($db, $_POST['time']);
  $seat = mysqli_real_escape_string($db, $_POST['seat']);
   $fare = mysqli_real_escape_string($db, $_POST['fare']);

  }
  	$query = "INSERT INTO ride (initial, destination, date, time, seat, fare) 
  			  VALUES('$initial', '$destination', '$date', '$time', '$seat', '$fare')";
  	mysqli_query($db, $query);

  	$_SESSION['success'] = "You are now logged in";
  	header('location: index1.php');
 ?>