<?php include('server.php') ?>
<!DOCTYPE html>
<html>
<head>
  <title>Registration system PHP and MySQL</title>
  <link rel="stylesheet" type="text/css" href="style.css">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="stylesheet" type="text/css" href="css/util.css">
	<link rel="stylesheet" type="text/css" href="css/main.css">
	    <script type="text/javascript" src="jquery-1.4.2.min.js"></script>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
</head>
<style>
body {font-family: Arial, Helvetica, sans-serif;}

.navbar {
  width: 100%;
  background-color: #555;
  overflow: auto;
}

.navbar a {
  float: right;
  padding: 12px;
  color: white;
  text-decoration: none;
  font-size: 18px;
}
.logo a {
  float: left;
  padding: 8px 30px 0px 30px;  
}
.navbar a:hover {
  background-color: #000;
}

.active {
  background-color: blue;
}

@media screen and (max-width: 500px) {
  .navbar a {
    float: none;
    display: block;
  }
}
</style>
<body>
<div class="navbar">
	<div class="logo">
		<a><img src="images/logo.png" class="imageHeader" title="Home Page" alt="Go to home" width="120" 
		height="38" position="left"/></a>
	</div>
  <a href="index.html"><i class="fa fa-fw fa-home"></i> Home</a> 
  <a href="#"><i class="fa fa-fw fa-search"></i> Trips</a> 
  <a href="#"><i class="fa fa-fw fa-envelope"></i> Contact</a> 
  <a class="active" href="register.php"><i class="fa fa-fw fa-user"></i> Sign Up</a>
   <a href="login.php"><i class="fa fa-fw fa-user"></i> Sign In</a>
</div>
<body>
  <div class="header">
  	<h2>Register</h2>
  </div>
	
  <form method="post" action="register.php">
  	<?php include('errors.php'); ?>
  	<div class="input-group">
  	  <label>Username</label>
  	  <input type="text" name="username" value="<?php echo $username; ?>">
  	</div>
  	<div class="input-group">
  	  <label>Email</label>
  	  <input type="email" name="email" value="<?php echo $email; ?>">
  	</div>
  	<div class="input-group">
  	  <label>Password</label>
  	  <input type="password" name="password_1">
  	</div>
  	<div class="input-group">
  	  <label>Confirm password</label>
  	  <input type="password" name="password_2">
  	</div>
  	<div class="input-group">
  	  <button type="submit" class="btn" name="reg_user">Register</button>
  	</div>
  	<p>
  		Already a member? <a href="login.php">Sign in</a>
  	</p>
  </form>><br><br><br><br><br>
  <!-- Footer -->
			<div class="navbar">
			  <a href="#"><i class="fa fa-facebook"></i></a> 
			  <a href="#"><i class="fa fa-google-plus"></i></a> 
			  <a href="#"><i class="fa fa-twitter"></i></a> 
			  <a href="#">@COOL POOL</a>				
			</div>
</body>
</html>