<?php
session_start();

// initializing variables
$username = "";
$email    = "";
$errors = array(); 

// connect to the database
$db = mysqli_connect('localhost', 'ictatjcu_easys', '123zxc', 'ictatjcu_easys');

// REGISTER USER
if (isset($_POST['submit'])) {
  // receive all input values from the form
  $name = mysqli_real_escape_string($db, $_POST['name']);
  $licence = mysqli_real_escape_string($db, $_POST['licence']);
  $plate = mysqli_real_escape_string($db, $_POST['plate']);
  

  }
  	$query = "INSERT INTO licence (name,licence,plate) 
  			  VALUES('$name', '$licence', '$plate')";
  	mysqli_query($db, $query);

  	header('location: addride.php');
 ?>