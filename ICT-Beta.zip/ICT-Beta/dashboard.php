

<?php
	$db = mysqli_connect('localhost', 'root', '', 'user');
	$query = "SELECT * FROM licence";
	$result = mysqli_query($db, $query);
	$row = mysqli_fetch_assoc($result);	
?>
<!DOCTYPE html>
<html>
<head>
	<title>trip</title>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="stylesheet" type="text/css" href="css/index.css">
	<link rel="stylesheet" type="text/css" href="css/main.css">
	<script type="text/javascript" src="jquery-1.4.2.min.js"></script>
	<link rel="stylesheet" type="text/css" href="style.css">
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
</head>
<!-- Header -->
<body>
	<div class="navbar">
		<div class="logo">
			<a><img src="images/logo.png" class="imageHeader" title="Home Page" alt="Go to home" width="120" 
			height="38" position="left"/></a>
		</div>
		<a  href="addride.php"><i class="fa fa-fw fa-user"></i> Add Ride</a>
		<a class='active' href="trip.php"><i class="fa fa-fw fa-search"></i> Trips</a> 
	</div>

<!-- Middle Section -->

	<table class="content-table" align="center" border="1px" style="width:600px; line-height:30px;">
		<thead>
			<tr>
			<th> Name </th>
			<th> Licence </th>
			<th> Plate </th>			
			</tr>
		</thead>
		<?php
		if($result -> num_rows >0){
			while($row = mysqli_fetch_assoc($result)) {
				?>
				<tr>
				<td><?php echo $row['name']; ?></td>
				<td><?php echo $row['licence']; ?></td>
				<td><?php echo $row['plate']; ?></td>
			
				</tr>
				<?php
			}
		}
		else
		{
			?>
			<tr>
			<th colspan="5"> No Data Found</th>
			</tr>
			<?php
		}
		?>
			
	</table>
	<br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br>
<!-- Footer -->
	<div class="navbar">
		<a href="#"><i class="fa fa-facebook"></i></a> 
		<a href="#"><i class="fa fa-google-plus"></i></a> 
		<a href="#"><i class="fa fa-twitter"></i></a> 
		<a href="#">@COOL POOL</a>				
	</div>
</body>
</html>