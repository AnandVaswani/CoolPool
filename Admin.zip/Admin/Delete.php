<html>
<head>
<?php
error_reporting(0);
include 'connection.php';
$name = $_post('user');

$sql = " Delete from Data where id=$name";

if($_post['submit'])
	{
	if(mysqli_query($conn, $sql)) 
		{
		echo"Data deleted successfully";
		
		}
		else
		{
		echo"something went wrong";
		}
	}
?>
</head>

<body>
<form action="delete.php" method="post">
	<h4> Give Id to delete the data</h4>
	
	ID: <input type="text" name="user">
	<input type="submit" name="submit" value="send info">
</form>
</body>

</html>