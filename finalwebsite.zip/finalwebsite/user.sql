-- phpMyAdmin SQL Dump
-- version 4.8.5
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jun 03, 2019 at 01:00 PM
-- Server version: 10.1.39-MariaDB
-- PHP Version: 7.3.5

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `user`
--

-- --------------------------------------------------------

--
-- Table structure for table `licence`
--

CREATE TABLE `licence` (
  `id` int(11) NOT NULL,
  `name` text NOT NULL,
  `licence` text NOT NULL,
  `plate` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `licence`
--

INSERT INTO `licence` (`id`, `name`, `licence`, `plate`) VALUES
(0, 'Gurpreet', '234567', '123456');

-- --------------------------------------------------------

--
-- Table structure for table `ride`
--

CREATE TABLE `ride` (
  `id` int(11) NOT NULL,
  `initial` varchar(20) NOT NULL,
  `destination` varchar(100) NOT NULL,
  `date` date NOT NULL,
  `time` time NOT NULL,
  `seat` varchar(5) NOT NULL,
  `fare` varchar(5) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `ride`
--

INSERT INTO `ride` (`id`, `initial`, `destination`, `date`, `time`, `seat`, `fare`) VALUES
(3, 'brisbane', 'Gold Coast', '2019-06-11', '17:00:00', '3', ''),
(4, 'brisbane', 'sydney', '2019-06-11', '11:58:00', '2', ''),
(5, 'Sydney', 'Melbourne', '2019-06-27', '14:00:00', '3', ''),
(6, 'vadodara', 'ahmedabad', '2019-06-05', '00:15:00', '2', ''),
(7, '', '', '0000-00-00', '00:00:00', '', ''),
(8, 'wer', 'rty', '2019-06-21', '14:00:00', '4', ''),
(9, 'delhi', 'mumbai', '2019-06-05', '03:30:00', '1', ''),
(10, 'delhi', 'mumbai', '2019-06-11', '14:02:00', '1', ''),
(11, 'd', 't', '2019-06-05', '13:01:00', '2', '$40'),
(12, 'f', 'j', '2019-06-05', '00:00:00', '3', '$50');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `username` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `password` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `username`, `email`, `password`) VALUES
(1, 'Gurpreet', 'kaurgurpreet1488@gmail.com', '15f16edd4c04e657c47577e4554e011b'),
(2, 'soni', 'soni@gmail.com', 'af469f821a329e345cc92633ab88d9cf'),
(3, 'sonika', 'sonika@gmail.com', '31da91ce115996be27adda1335f109ee'),
(4, 'Sandeep', 'luckie@gmail.coom', '202cb962ac59075b964b07152d234b70'),
(5, 'abc', 'abc@gmail.com', '900150983cd24fb0d6963f7d28e17f72'),
(6, 'zxc', 'zxc@gmail.com', '5fa72358f0b4fb4f2c5d7de8c9a41846'),
(7, 'qwe', 'qwe@gmail.com', '76d80224611fc919a5d54f0ff9fba446'),
(8, 'sdf', 'sdf@gmail.com', 'd9729feb74992cc3482b350163a1a010'),
(9, 'bnm', 'bnm@gmail.com', 'bd93b91d4a5e9a7a5fcd1fad5b9cb999');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `ride`
--
ALTER TABLE `ride`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `ride`
--
ALTER TABLE `ride`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
