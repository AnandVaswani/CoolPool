<?php include('server.php') ?>
<?php
	$db = mysqli_connect('localhost', 'root', '', 'user');
	$query = "SELECT * FROM ride";
	$result = mysqli_query($db, $query);
	$row = mysqli_fetch_assoc($result);	
?>
<!DOCTYPE html>
<html>
<head>
  <title>Add Ride</title>
  <link rel="stylesheet" type="text/css" href="style.css">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
</head>
<style>
body {font-family: Arial, Helvetica, sans-serif;}

.navbar {
  width: 100%;
  background-color: #555;
  overflow: auto;
}

.navbar a {
  float: right;
  padding: 12px;
  color: white;
  text-decoration: none;
  font-size: 17px;
}

.navbar a:hover {
  background-color: #000;
}

.active {
  background-color: blue;
}

@media screen and (max-width: 500px) {
  .navbar a {
    float: none;
    display: block;
  }
}

.content-table{
  border-collapse: collapse;
  margin: 25px 0;
  font-size: 0.9em;
  min-width: 400px;
  border-radius: 5px 5px 0 0;
  overflow: hidden;
  box-shadow: 0 0 20px rgba(0,0,0,0.15)

}
.content-table thead tr{
  background-color: #388CC5;
  color: #ffffff;
  text-align: left;
  font-weight: bold;
}

.content-table th,
.content-table td {
  padding: 12px 15px;
}

.content-table tbody tr{
  border-bottom: 1px solid #dddddd;

}
.content-table tbody tr:nth-of-type(even){
  background-color: #f3f3f3;

}
.content-table tbody tr:last-of-type{
  border-bottom: 2px solid #388CC5;

}
</style>
<body>
<div class="navbar">
<?php  if (isset($_SESSION['username'])) : ?>
    		<a href="trip.php"><i></i><p>Welcome <strong><?php echo $_SESSION['username']; ?></strong></p>
    	<p> <a href="index.html?logout='1'" style="color: white;">logout</a> </p>
    <?php endif ?>
	<a  href="licence.php"><i class="fa fa-fw fa-user"></i> Add Ride</a>
	<a  href="trip.php"><i class="fa fa-fw fa-search"></i> Trips</a> 
</div>	
		<center>
		<table  class="content-table" align="center" border="1px" style="width:600px; line-height:30px;">
		<thead>
			<tr>
			<form action="" method="POST" role="form">
			
			<th> From </th>
			<th> Destination </th>
			<th> Date </th>
			<th> Time </th>
			<th> Seat </th>
			<th> Fare </th>
			<th> Book </th>
			</tr>
		</thead>
		<?php
		if($result -> num_rows >0){
			while($row = mysqli_fetch_assoc($result)) {
				?>
				<tr>
				
				<td><?php echo $row['initial']; ?></td>
				<td><?php echo $row['destination']; ?></td>
				<td><?php echo $row['date']; ?></td>
				<td><?php echo $row['time']; ?></td>
				<td><?php echo $row['seat']; ?></td>
				<td><?php echo $row['fare']; ?></td>
				<td><button type="submit" class="btn" name="book">Book</button></td>
				</tr>
				<?php
			}
		}
		else
		{
			?>
			<tr>
			<th colspan="5"> No Data Found</th>
			</tr>
			<?php
		}
		?>
	
		
	</table></center><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br>
	<!-- Footer -->
			<div class="navbar">
			  <a href="#"><i class="fa fa-facebook"></i></a> 
			  <a href="#"><i class="fa fa-google-plus"></i></a> 
			  <a href="#"><i class="fa fa-twitter"></i></a> 
			  <a href="#">@COOL POOL</a>				
			</div>
</body>
</html>	
	
	
	
	
	
